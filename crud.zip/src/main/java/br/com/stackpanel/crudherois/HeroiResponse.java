package br.com.stackpanel.crudherois;

public record HeroiResponse(Long id, String nome, Integer vida) {
}
