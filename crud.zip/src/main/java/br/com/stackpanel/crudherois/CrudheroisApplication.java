package br.com.stackpanel.crudherois;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudheroisApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudheroisApplication.class, args);
	}

}
