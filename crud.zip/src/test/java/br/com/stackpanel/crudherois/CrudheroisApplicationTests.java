package br.com.stackpanel.crudherois;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudheroisApplicationTests {

	@Test
	void contextLoads() {
	}

}
